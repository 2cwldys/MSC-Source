Stripper2 - A Half-Life metamod plugin by botman (botman@planethalflife.com)

You should extract these files to your Metamod-X.XX.XX folder like so...

metamod-1.11.00\
               \dlls
               \doc
               \entities
               \metamod
               \stripper2_plugin\
                                \common
                                \dlls
                                \engine
               \stub_plugin
               \trace_plugin
               \wdmisc_plugin

Then build using Microsoft Visual C++ 6.0 (or run make on Linux machines).

The Stripper2 plugin is released under the GNU GPL license.  You are free
to use the source code included with this plugin in any project that you
wish as long as you also release the source code to your project as well.
